// Decompiled by DJ v2.9.9.61 Copyright 2000 Atanas Neshkov  Date: 2003-1-22 10:24:55
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   cmppe_result.java

package comsd.commerceware.cmpp;


public class cmppe_result
{

    public cmppe_result()
    {
    }

    public int stat;
    public int pack_id;
}