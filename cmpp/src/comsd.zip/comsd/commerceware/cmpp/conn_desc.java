// Decompiled by DJ v2.9.9.61 Copyright 2000 Atanas Neshkov  Date: 2003-1-22 10:26:52
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   conn_desc.java
package comsd.commerceware.cmpp;

import java.net.Socket;

public final class conn_desc
{

    public conn_desc()
    {
    }

    public Socket sock; //����
    public int seq;    //���
    public int status;
}