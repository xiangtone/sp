// Decompiled by DJ v2.9.9.61 Copyright 2000 Atanas Neshkov  Date: 2003-1-22 10:20:24
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   cmppe_head.java

package comsd.commerceware.cmpp;


public final class cmppe_head
{

    public cmppe_head()
    {
    }

    protected int pk_len;
    protected int pk_cmd;
    protected int pk_stat;
    protected int pk_seq;
}