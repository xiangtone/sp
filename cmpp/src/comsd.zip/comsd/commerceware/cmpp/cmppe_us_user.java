// Decompiled by DJ v2.9.9.61 Copyright 2000 Atanas Neshkov  Date: 2003-1-22 10:26:14
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   cmppe_us_user.java

package comsd.commerceware.cmpp;


public class cmppe_us_user
{

    public cmppe_us_user()
    {
    }

    public byte index;
    public byte stat;
}