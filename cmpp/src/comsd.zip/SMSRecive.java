/*
 * Created on 2006-11-15
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.io.*;
import java.util.Vector;
import java.text.SimpleDateFormat;
import comsd.commerceware.cmpp.*;
import com.xiangtone.util.MyTools;
import com.xiangtone.util.FormatSysTime;
public class SMSRecive implements Runnable{
	 CMPP p = new CMPP(); 
	 conn_desc con = new conn_desc();
	 cmppe_deliver_result cd = new cmppe_deliver_result();
	 cmppe_submit_result sr = new cmppe_submit_result();
	 cmppe_result  cr = new cmppe_result();
	 public SMSoperate handle;
	 public CMPPSingleConnect cmppcon ;
	 public  static final String ISMGID = "01";
	 public SMSRecive()
	 {
	 	handle = new SMSoperate();
		cmppcon = CMPPSingleConnect.getInstance();
		con = cmppcon.con;
	 }
	 
	 public void run(){
	 	while(true){
	 		try{
	 			 p.readPa(con);
	    		 Thread.currentThread().sleep(200);
	    		 if(sr.flag == 0) //submit resp
	    		    {
	    		      	 sr.flag = -1;   //��λ 
	    		      	 String str_resp_msgId = MyTools.Bytes2HexString(sr.msg_id);
	    		      	 int    i_resp_result = sr.result;
	    		      	 int    i_resp_seq    = sr.seq;
	    		      	 
	    		      	 System.out.println("sr.result:"+i_resp_result);
	    		      	 System.out.println("sr.seq:"+i_resp_seq);
	    		      	 System.out.println("sr.msg_id:"+str_resp_msgId);
	    		      	 handle.receiveSubmitResp(this.ISMGID,(int)i_resp_seq,(String)str_resp_msgId,(int)i_resp_result);
	    		    }
	    		   if(cd.STAT == 0) //˵������Ϣ������
    		    {
    		    	cd.STAT = -1;
    		      	System.out.println("����Ϣ������...");
    		      	/////////////////////////////
    		      	
    		        String str_ismgid = this.ISMGID;
    		        String str_spcode = cd.getSPCode();
    		        String str_cpn    = cd.getCpn();
    		        int 	cpn_type = cd.getsrcType();//add 061121
    		        int    i_len      = cd.getLen();
    		        int    i_fmt      = cd.getFmt();
    		        int    i_tp_udhi  = cd.get_tp_udhi();
    		        String str_svc_type  = cd.getServerType();
    		        String link_id = cd.getLinkId();
    		        
    		        byte[] str_content=cd.getMessage();
    		        
    		        
    		        int    i_report_flag = cd.getRegistered_delivery(); //״̬�����
    		      	System.out.println("i_report_flag:"+ i_report_flag);
    		      	if(i_report_flag == 1)
    		      	{   
    		      		System.out.println("״̬������Ϣ....");
    		      		String report_dest_cpn    = cd.get_dest_cpn();	
    		      		String msg_id      = MyTools.Bytes2HexString(cd.get_msg_id());
    		      		String submit_time = cd.get_submit_time();
    		      		String done_time   = cd .get_done_time();
    		      		String stat2       = cd.get_stat();
    		      		System.out.println("stat2:"+stat2);
    		      		int stat_dev=0;
    		      		if(stat2.equals("DELIVRD"))
    		      			stat_dev=0;
    		      		else
    		      			stat_dev=-1;
    		      		handle.receiveReport(this.ISMGID,msg_id,report_dest_cpn,str_spcode,str_cpn,submit_time,done_time,stat_dev);
    		      		continue;
    		      	}
    		      	cd.printAll(); //��ӡmo��Ϣ;
    		      	
    		      	///////////////////////////////
    		      		handle.setDeliver_ismgID(str_ismgid);
								//handle.setDeliver_msgID(String _msgID)
									handle.setDeliver_spCode(str_spcode);
									handle.setDeliver_serverID(str_svc_type);
									handle.setDeliver_fmt(i_fmt);
									handle.setDeliver_srcCpn(str_cpn);
									handle.setDeliver_srcCpnType(cpn_type);//�ֻ���������� α�뻹�����롣
									handle.setDeliver_contentLen(i_len);
									handle.setDeliver_content(str_content);
									handle.setDeliver_linkId(link_id);
    		      		handle.receiveDeliver();  	
    		    }  	   
	 		}catch(Exception e){
	 			System.out.println(e.toString());
    		System.out.println("��������....");
    		p.cmpp_disconnect_from_ismg(con);
  			cmppcon.destroy();
  						cmppcon = CMPPSingleConnect.getInstance(); //����
  						con = cmppcon.con;
	 		}
	 	}
	 }
}
