/*
 * Created on 2006-11-15
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * ���ڷ����������Ӳ��԰���
 */
import comsd.commerceware.cmpp.*;
import java.lang.*;
import java.io.*;
public class SMSActiveTest implements Runnable {
	CMPP p = new CMPP();
  	public static conn_desc con = new conn_desc();
  	cmppe_login cl = new cmppe_login();
  	CMPPSingleConnect cmppcon = CMPPSingleConnect.getInstance();
  	
  	public SMSActiveTest() 
  	{		
  					
  	}
  	/**
  	*
  	*
  	*/
  	public void run()
  	{
  		try
  		{
  			
  				while(true)
  				{
  					System.out.println("-------send active test -------");
  					if(cmppcon == null )
  					{
  						cmppcon = CMPPSingleConnect.getInstance();
  					}
                	try
                	{	
                		p.cmpp_active_test(cmppcon.con);
                	}
                	catch(Exception e)
                	{
                		System.out.println(e.toString());
                		System.out.println("��������...");
    		    	    p.cmpp_disconnect_from_ismg(con);
    		    	    cmppcon =null;
    		    	    cmppcon = CMPPSingleConnect.getInstance(); //����
                	}
  					Thread.currentThread().sleep(10000);
  			}
  			
  		}
  		catch(Exception e)
  		{
  			System.out.println(e.toString());
  		}	
  	}	 	
}
