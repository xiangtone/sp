/**
*Copyright 2003 Xiamen Xiangtone Co. Ltd.
*All right reserved.
*/


import java.util.*;
import java.io.*;
import java.sql.*;

/**
*this Class operate gamelisttbl
*
*/
public class SMSUserSchedule
{
	/**
	*
	*/
	 mysqldb db ;
	 ResultSet rs = null;
	 String strSql;
	 public static final int SPCODE_LEN=5; //�����ų���
	 public static final int CORP_LEN=2;//ý��ų���
	 public static final int GAME_LEN=3;//��Ϸ�ų���
	 
	 String gameCode="";
	 String spCode="";
	 String gameID="";
	 String corpID="00";
	 String actionCode="";
	 public String serverID="8003";
	 int vcpID=1;
	 
	 /**
	 * get method
	 *
	 */
	 
	 public String getUSched_gameCode() { return gameCode;}
	 public String getUSched_serverID(){return getServerIDbyServerName(getUSched_gameCode());}
	 public String getUSched_spCode() { return spCode;}
	 public String getUSched_actionCode() { return actionCode;}
	 public int    getUSched_vcpID() { return vcpID;}
	 public String getUSched_corpID(){return corpID;}
     /**
      *
      *
      */
     public SMSUserSchedule()
     {
     	if(db ==null)
     	{
     		db = new mysqldb();
     	}
    }



	/**
	*ȡ�����ս��
	*��Ϸ����
	*
	*/
	public void getUserDetail(String spcode,String info)
	{
		this.serverID="8003";
		this.vcpID=1;
		this.spCode = spcode;
		String content = info.toUpperCase().trim();
		if(isItemExist(content))
		{
			if(this.spCode.length()>5)
			{
				this.spCode = this.spCode.substring(0,5);
				this.spCode +="00"+this.gameID;
				this.actionCode="";
				this.gameCode = content;
				return;
			}
			
		}
		
		int offset = content.indexOf(" ",0);//�жϿո�
		if(offset >0)
		{
		 	gameCode = content.substring(0,offset);
		 	actionCode = content.substring(offset+1);
		}
		else
		{
			gameCode=content;
			actionCode="";
		}
		if(isItemExist(gameCode))
		{
			this.gameCode = gameCode;
		}
		else
		{
			this.gameCode = "ERROR";
			this.actionCode = content;
		}

		
		int len = spCode.length();
		switch(len)
		{
			case SPCODE_LEN:
					if(isItemExist(gameCode))
					{
						this.gameCode = gameCode;
						this.gameID =this.gameID;
						this.vcpID = this.vcpID;
						this.corpID="00";
						this.spCode=this.spCode+this.corpID+this.gameID;
					}
					else
					{
						this.gameCode = "ERROR";
						this.vcpID = 1;
					}	
					break;
			case SPCODE_LEN+CORP_LEN:
					String strspcode = spCode.substring(0,SPCODE_LEN);
					String strcorpId = spCode.substring(SPCODE_LEN,SPCODE_LEN+CORP_LEN);
					if(!isCorpIDExist(strcorpId))
					{
						this.corpID = "00";
						this.spCode = strspcode+this.corpID;
					}
					if(isItemExist(gameCode))
					{
						this.spCode = this.spCode+this.gameID;
					}
					else
					{
						this.vcpID = 1;
						this.gameCode = "ERROR";
					}
					break;
			case SPCODE_LEN+CORP_LEN+GAME_LEN:
					String _strspcode = spCode.substring(0,SPCODE_LEN);
					String _strcorp = spCode.substring(SPCODE_LEN,SPCODE_LEN+CORP_LEN);
					String _strgame = spCode.substring(SPCODE_LEN+CORP_LEN,SPCODE_LEN+CORP_LEN+GAME_LEN);
					if(!isCorpIDExist(_strcorp))
					{
						this.corpID = "00";
						this.spCode = _strspcode+this.corpID+_strgame;
					}
					if(!isGameIDExist(_strgame))
					{
						this.gameCode ="ERROR";
						this.spCode = _strspcode;
					}
					System.out.println("***********this.vcpID:"+this.vcpID);
					
					break;
			default:
					this.spCode = spCode.substring(0,5);
					if(isItemExist(gameCode))
					{
						this.gameCode=this.gameCode;
						this.corpID ="00";
						this.spCode=this.spCode+this.corpID+this.gameID;
					}
					else
					{
						this.gameCode = "ERROR";
						this.vcpID =1;
				         }
						
					 
					break;
		}

	}
	/**
	*
	*
	*/
	public boolean isItemExist(String strGameCode)
	{
                
		boolean flag = false;
		try
		{
			strSql="select * from sms_gamelist where gamename='"+strGameCode+"'";
			rs = db.execQuery(strSql);
			if(rs.next())
			{
				flag = true;
				this.gameID = rs.getString("gameid");
				this.gameCode = rs.getString("gamename");
				
				this.vcpID = rs.getInt("vcpid");
			}
		}
		catch(Exception e)
		{ 
			System.out.println(e.toString());
		}
		return flag;
	}
	
	/**
	*
	*
	*/
	public boolean isGameIDExist(String gameId)
	{
		boolean flag = false;
		try
		{
			strSql = "select * from sms_gamelist where gameid='"+gameId+"'";
			System.out.println("strSql:"+strSql);
			rs = db.execQuery(strSql);
			if(rs.next())
			{
				flag = true;
				this.gameCode = rs.getString("gamename"); 
				this.serverID = getServerIDbyServerName(this.gameCode);
				this.gameID = rs.getString("gameid");
				//this.gameID = gameId;
				this.vcpID = rs.getInt("vcpid");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return flag;
	}
	/**
	*������ں������id �ͷ���
	*�����ھ�ʹ��Ĭ��
	*/
	public boolean isCorpIDExist(String id)
	{
		strSql = "select * from sms_company where corp_id='"+id+"'";
		try
		{
			rs = db.execQuery(strSql);
			if(!rs.next())
				return false;
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
		this.corpID = id;
		return true;
			
	}	
	/**
	 *ͨ��servername �õ�serverid
	 *
	 */
	private String getServerIDbyServerName(String servername)
	{

		strSql = "select * from sms_cost where servername='"+servername+"' limit 1";
		try
		{
			ResultSet rs2 = db.execQuery(strSql);
			if(rs2.next())
			{
				String _serverid = rs2.getString("serverid");
				return _serverid;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return this.serverID;
	}
			
	 
	

	
	public static void main(String[] args)
	{
		SMSUserSchedule sms = new SMSUserSchedule();
		sms.getUserDetail(args[0],args[1]);
		String game_code = sms.getUSched_gameCode();
		String sp_code = sms.getUSched_spCode();
		String action_code = sms.getUSched_actionCode();
		int vcp_id = sms.getUSched_vcpID();
		String corp_id = sms.getUSched_corpID();
		String server_id = sms.getUSched_serverID();
		
	    System.out.println("game_code:"+game_code);
	    System.out.println("sp_code:"+sp_code);
	    System.out.println("action_code:"+action_code);
	    System.out.println("vcp_id:"+vcp_id);
	    System.out.println("corp_id:"+corp_id);
	    System.out.println("serverid:"+server_id);
	}
	    
	    
	
}