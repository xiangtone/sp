/**
*Copyright 2003 Xiamen Xiangtone Co. Ltd.
*All right reserved.
*/
package com.xiangtone.sms.api;

public final class sm_header
{

    public sm_header()
    {
    }

    protected int pk_len;
    protected int pk_cmd;
}