/**
*Copyright 2003 Xiamen Xiangtone Co. Ltd.
*All right reserved.
*/
package com.xiangtone.sms.api;


public class sm_result
{

    public sm_result()
    {
    }
    public int pack_cmd;
}