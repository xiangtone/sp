
package com.xiangtone.sms.webapi;

public class sm_result
{

    public sm_result()
    {
    }
    public int pack_type;
}