package com.xiangtone.sms.webapi;
//��Ϣͷ


public final class sm_header
{

    public sm_header()
    {
    }
    protected int  pk_type;
    protected int  pk_len;

}