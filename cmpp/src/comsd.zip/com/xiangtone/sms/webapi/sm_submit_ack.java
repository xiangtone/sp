package com.xiangtone.sms.webapi;
public class sm_submit_ack
{
	public sm_submit_ack()
	{
	}
}